package com.example.ipaylight;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class DashboardActivity extends AppCompatActivity {
    CardView depotCard;
    CardView retraitCard;
    CardView transferWithCode;
    CardView transferToAccount;
    CardView retraitOrder;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        depotCard = findViewById(R.id.depotCardId);
        retraitCard =  findViewById(R.id.retraitCardId);
        transferWithCode = findViewById(R.id.tranferCardWithCodeId);
        transferToAccount = findViewById(R.id.transferToAccountId);
        retraitOrder = findViewById(R.id.retraitOrderId);
        depotCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), DepotActivity.class);
                startActivity(intent);
            }
        });
        retraitCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), RetraitActivity.class);
                startActivity(intent);
            }
        });
        transferWithCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), TransferCodeActivity.class);
                startActivity(intent);
            }
        });
        transferToAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), TransferAccountActivity.class);
                startActivity(intent);
            }
        });
        retraitOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), OrderRetraitActivity.class);
                startActivity(intent);
            }
        });
    }
}
