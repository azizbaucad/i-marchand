package com.example.ipaylight;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.PropertyInfo;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;

import com.example.ipaylight.helper.DatabaseHelper;

public class LoginActivity extends AppCompatActivity {
    DatabaseHelper myDb;
    String URL = "http://50.116.97.25:8080/cash-ws/CashWalletServiceWS?wsdl";
    String NAMESPACE = "http://runtime.services.cash.innov.sn/";
    String SOAP_ACTION = "";
    String METHOD_NAME = "login";
    private EditText loginEdit;
    private EditText passwordText;
    String login;
    String password;
    public String token;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        myDb = new DatabaseHelper(this);
        Button btn_con = findViewById(R.id.loginBtn);
        loginEdit = findViewById(R.id.emailOubTxt);
        passwordText = findViewById(R.id.passworOubTxt);

        btn_con.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (loginEdit.getText().length() != 0 && !loginEdit.getText().toString().equals("")) {
                    if(passwordText.getText().length() != 0 && !passwordText.getText().toString().equals("")) {
                        AsyncCallWS task = new AsyncCallWS();
                        task.execute();
                    }  //If Password text control is empty
                    else{
                        passwordText.setError("Entrez le mot de passe");
                    }
                }else {
                    passwordText.setError("Entrez le login");
                }
            }
        });

    }
    @SuppressLint("StaticFieldLeak")
    class AsyncCallWS extends AsyncTask<String, Void, String> {
        private ProgressDialog Dialog = new ProgressDialog(LoginActivity.this);

        @Override
        protected String doInBackground(String... url) {
            loginAction();
            return null;
        }

        @Override
        protected void onPreExecute() {
            Dialog.setMessage("chargement...");
            Dialog.show();
        }

        @Override
        protected void onPostExecute(String result) {
            Dialog.dismiss();

        }

        private void loginAction() {
            SoapObject request = new SoapObject(NAMESPACE, METHOD_NAME);

            login = loginEdit.getText().toString();
            password = passwordText.getText().toString();

            //Pass value for userName variable of the web service
            PropertyInfo unameProp =new PropertyInfo();
            unameProp.setName("login");//Define the variable name in the web service method
            unameProp.setValue(login);//set value for userName variable
            unameProp.setType(String.class);//Define the type of the variable
            request.addProperty(unameProp);//Pass properties to the variable

            //Pass value for Password variable of the web service
            PropertyInfo passwordProp =new PropertyInfo();
            passwordProp.setName("password");
            passwordProp.setValue(password);
            passwordProp.setType(String.class);
            request.addProperty(passwordProp);

            //Pass value for Password variable of the web service
            String mod = "APP";
            PropertyInfo mode =new PropertyInfo();
            mode.setName("mode");
            mode.setValue(mod);
            mode.setType(String.class);
            request.addProperty(mode);
            try {
                SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
                envelope.setOutputSoapObject(request);
                HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
                androidHttpTransport.call(SOAP_ACTION, envelope);
                SoapObject result = (SoapObject) envelope.getResponse();
                System.out.println("call Donnnnnnnnnnnnnnnnnnnnnnnnnnne");
                String erreur = result.getProperty(0).toString();
                // String iduser = result.getProperty(1).toString();
                String message1 = result.getProperty(2).toString();
                // String nom = result.getProperty(3).toString();
                //String prenom = result.getProperty(4).toString();
                String profil = result.getProperty(5).toString();
                String telephone = result.getProperty(6).toString();
                token  = result.getProperty(7).toString();

                boolean isInserted = myDb.insertData(token,null, null,telephone);

                Log.e("result", "responceEEEEEEEEEEEEEEEEEEEEEEEE" + result);
                Log.e("token", "tokennnn" + token);

                Log.e("result", "Message1 " + message1);
                Log.d("LOG_TAG", envelope.bodyIn.toString());
                Log.d("LOG_TAG", envelope.bodyIn.toString());
                if (erreur.equals("0") && profil.equals("CLIENT") && isInserted ){
                    Log.e("result", "donnéeeeeeeeeeeeees inséréééééééés" + token);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Intent i = new Intent(getApplicationContext(), DashboardActivity.class);
                            startActivity(i);
                        }
                    });
                }else
                {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(LoginActivity.this, "identifiants incorrects ou Le user a deja une session en cours", Toast.LENGTH_LONG).show();
                        }
                    });
                }

            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }
}
